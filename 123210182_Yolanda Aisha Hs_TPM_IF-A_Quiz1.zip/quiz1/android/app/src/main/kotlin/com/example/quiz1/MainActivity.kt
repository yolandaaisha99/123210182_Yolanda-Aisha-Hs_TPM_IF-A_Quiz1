package com.example.quiz1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
